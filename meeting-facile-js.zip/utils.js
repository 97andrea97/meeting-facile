function getUserColor(user) { /* logic in utils.js */ }
function clipSlotToRange(slot, settings) { /* logic in utils.js */ }
function mergeSlots(slots) { /* logic in utils.js */ }
function findCommonSlots(usersSlots) { /* logic in utils.js */ }
function intersectTwo(a, b) { /* logic in utils.js */ }

let firstSummaryUpdate = true;

function updateSummaries(settings) { /* logic in summary.js */ }
function showAllUserSummaries(mergedByUser, firstLoad = false) { /* logic in summary.js */ }
function showSummary(containerId, slots, className) { /* logic in summary.js */ }

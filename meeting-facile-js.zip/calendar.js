let calendar;

function createCalendar(settings) { /* logic in calendar.js */ }

function loadUserAvailability() { /* logic in availability.js */ }
function saveAvailability() { /* logic in availability.js */ }
function saveAvailabilityAndUpdate() { /* logic in availability.js */ }
